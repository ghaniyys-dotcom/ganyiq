# GANYIQ Worker — Phase A Stable

## Quick Start

1. Install Node.js (v18+) and Python (3.10+)
2. Install ffmpeg (https://ffmpeg.org/download.html)
3. Open terminal in this directory

### Install dependencies

```cmd
npm install
pip install -r requirements.txt
```

### Configure

Rename `env-template.txt` to `.env.local` and fill in:

```
GANYIQ_API_URL=https://ganyiq.ganys.me
DEEPGRAM_API_KEY=your_deepgram_key_here
WORKER_NAME=PC-GANY
```

### Run

```cmd
npx tsx index.ts
```

## Phase A Stabilization (June 2026)

Memory-heavy features are OPT-IN by default:

| Feature | Enable with | What it does |
|---------|-------------|--------------|
| Layout transitions | `GANYIQ_FEATURE_LAYOUT_TRANSITIONS=1` | Ken Burns zoom, crossfade, slide-in animations |
| Audio reaction detection | `GANYIQ_FEATURE_REACTION_DETECTION=1` | librosa laughter/gasp detection |
| Visual reaction detection | `GANYIQ_FEATURE_VISUAL_REACTION=1` | Face landmark smile/surprise detection |

Add these to `.env.local` to enable. Disabled by default for stability.

## Verify Worker Health

Worker auto-registers on first run. Check:
- Logs show: `[REGISTER] Registered as worker N — auth token saved`
- Backend: `https://ganyiq.ganys.me/api/health`
